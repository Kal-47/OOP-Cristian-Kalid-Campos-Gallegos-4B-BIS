# exceptions.py
# Responsibility (SRP): define the custom exceptions of the inventory system.
# Nothing else lives here: no logic, no input/output.

class ErrorInventario(Exception):
    """Base class for every inventory error.
    Catching ErrorInventario in main.py also catches all the subclasses below."""
    pass


class ProductoNoEncontrado(ErrorInventario):
    """The product code does not exist in the inventory."""
    pass


class CantidadInvalida(ErrorInventario):
    """The quantity is zero, negative, or not an integer."""
    pass


class StockInsuficiente(ErrorInventario):
    """The requested quantity is greater than the available stock."""
    pass
