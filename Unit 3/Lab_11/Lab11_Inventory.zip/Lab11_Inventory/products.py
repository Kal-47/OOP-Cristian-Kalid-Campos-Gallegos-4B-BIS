# products.py
# Responsibility (SRP): represent ONE product and protect its own stock.
# It validates the withdrawal, but it does not print or ask for input.

from exceptions import CantidadInvalida, StockInsuficiente


class Producto:
    def __init__(self, codigo, stock):
        self.codigo = codigo
        self.stock = stock

    def retirar(self, cantidad):
        """Deduct 'cantidad' from the stock and return the remaining stock."""

        # Step 1: the quantity must be a positive integer.
        # isinstance(..., int) rejects texts and decimals; bool is excluded
        # because True/False are technically ints in Python.
        # 'raise' stops the method here and sends the error to whoever called it.
        if isinstance(cantidad, bool) or not isinstance(cantidad, int) or cantidad <= 0:
            raise CantidadInvalida("la cantidad debe ser un entero mayor a cero")

        # Step 2: there must be enough stock.
        if cantidad > self.stock:
            raise StockInsuficiente(
                f"stock disponible: {self.stock}, cantidad solicitada: {cantidad}"
            )

        # Step 3: both validations passed, so it is safe to modify the stock.
        # The stock is only changed AFTER validating, so an invalid operation
        # never modifies it.
        self.stock -= cantidad
        return self.stock
