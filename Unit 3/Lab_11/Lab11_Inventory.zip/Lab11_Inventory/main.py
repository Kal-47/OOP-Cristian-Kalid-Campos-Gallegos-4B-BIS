# main.py
# Responsibility (SRP): talk to the user (input/output) and handle the errors.

from inventory import Inventario
from exceptions import ErrorInventario


def main():
    inventario = Inventario()
    codigo = input("Codigo del producto: ").strip()

    # 'try' runs the code that can fail.
    try:
        # int() raises ValueError if the text is not an integer (e.g. "abc").
        cantidad = int(input("Cantidad a retirar: "))
        # This can raise ProductoNoEncontrado, CantidadInvalida or
        # StockInsuficiente. They all inherit from ErrorInventario.
        stock_restante = inventario.retirar(codigo, cantidad)

    # 'except' runs only if the matching error happened in the 'try' block.
    except ValueError:
        print("La cantidad debe ser un número entero")
    except ErrorInventario as error:
        # type(error).__name__ shows which custom exception was raised.
        print(f"No se pudo realizar la operacion ({type(error).__name__}): {error}")

    # 'else' runs ONLY if the 'try' block finished without any exception.
    else:
        print("Retiro realizado. Stock restante:", stock_restante)


if __name__ == "__main__":
    main()
