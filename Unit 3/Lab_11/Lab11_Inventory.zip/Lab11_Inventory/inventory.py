# inventory.py
# Responsibility (SRP): keep the collection of products and find the right one.
# It does not validate quantities (that is Producto's job) and it does not
# talk to the user (that is main.py's job).

from products import Producto
from exceptions import ProductoNoEncontrado


class Inventario:
    def __init__(self):
        # Dictionary: product code -> Producto object
        self.productos = {
            "P01": Producto("P01", 5),
            "P02": Producto("P02", 5),
            "P03": Producto("P03", 5),
            "P04": Producto("P04", 10),   # additional product
            "P05": Producto("P05", 3),    # additional product
        }

    def retirar(self, codigo, cantidad):
        """Withdraw 'cantidad' units of the product 'codigo'.
        Returns the remaining stock."""

        # Step 4: verify that the product exists.
        if codigo not in self.productos:
            raise ProductoNoEncontrado(f"el producto '{codigo}' no existe")

        # Step 5: delegate the withdrawal to the Producto object.
        # There is no try/except here on purpose: CantidadInvalida and
        # StockInsuficiente raised by Producto propagate (go up) to main.py.
        return self.productos[codigo].retirar(cantidad)
